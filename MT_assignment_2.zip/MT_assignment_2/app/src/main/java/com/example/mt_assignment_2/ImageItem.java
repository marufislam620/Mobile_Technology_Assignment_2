package com.example.mt_assignment_2;

public class ImageItem {
    private String id;
    private String title;
    private String resultText;
    private String imageFileName;
    private long createdAt;

    public ImageItem() {
        // Required empty constructor for Firebase
    }

    public ImageItem(String id, String title, String resultText, String imageFileName, long createdAt) {
        this.id = id;
        this.title = title;
        this.resultText = resultText;
        this.imageFileName = imageFileName;
        this.createdAt = createdAt;
    }

    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getResultText() {
        return resultText;
    }

    public String getImageFileName() {
        return imageFileName;
    }

    public long getCreatedAt() {
        return createdAt;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setResultText(String resultText) {
        this.resultText = resultText;
    }

    public void setImageFileName(String imageFileName) {
        this.imageFileName = imageFileName;
    }

    public void setCreatedAt(long createdAt) {
        this.createdAt = createdAt;
    }
}