package com.example.mt_assignment_2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class ListActivity extends AppCompatActivity {

    private ListView listViewImages;
    private Button btnAdd;

    private DatabaseReference databaseReference;
    private ValueEventListener valueEventListener;

    private ArrayList<ImageItem> imageItems;
    private ImageItemAdapter imageItemAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        listViewImages = findViewById(R.id.listViewImages);
        btnAdd = findViewById(R.id.btnAdd);

        databaseReference = FirebaseDatabase.getInstance().getReference("analysedImages");

        imageItems = new ArrayList<>();
        imageItemAdapter = new ImageItemAdapter(this, imageItems);
        listViewImages.setAdapter(imageItemAdapter);

        btnAdd.setOnClickListener(view -> {
            Intent intent = new Intent(ListActivity.this, MainActivity.class);
            startActivity(intent);
        });

        listViewImages.setOnItemClickListener((parent, view, position, id) -> {
            ImageItem selectedItem = imageItems.get(position);

            Intent intent = new Intent(ListActivity.this, DetailActivity.class);
            intent.putExtra(EditActivity.EXTRA_ITEM_ID, selectedItem.getId());
            startActivity(intent);
        });

        loadItemsFromFirebase();
    }

    private void loadItemsFromFirebase() {
        valueEventListener = databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                ArrayList<ImageItem> loadedItems = new ArrayList<>();

                for (DataSnapshot childSnapshot : snapshot.getChildren()) {
                    ImageItem item = childSnapshot.getValue(ImageItem.class);

                    if (item != null) {
                        if (item.getId() == null || item.getId().trim().isEmpty()) {
                            item.setId(childSnapshot.getKey());
                        }

                        loadedItems.add(item);
                    }
                }

                Collections.sort(loadedItems, new Comparator<ImageItem>() {
                    @Override
                    public int compare(ImageItem item1, ImageItem item2) {
                        return Long.compare(item2.getCreatedAt(), item1.getCreatedAt());
                    }
                });

                imageItemAdapter.updateItems(loadedItems);

                if (loadedItems.isEmpty()) {
                    Toast.makeText(ListActivity.this, "No analysed images saved yet.", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Toast.makeText(ListActivity.this, "Firebase load failed: " + error.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (databaseReference != null && valueEventListener != null) {
            databaseReference.removeEventListener(valueEventListener);
        }
    }
}