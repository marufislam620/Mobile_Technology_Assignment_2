package com.example.mt_assignment_2;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.barcode.BarcodeScannerOptions;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.label.ImageLabel;
import com.google.mlkit.vision.label.ImageLabeler;
import com.google.mlkit.vision.label.ImageLabeling;
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.io.File;
import java.util.Locale;

public class AnalyseActivity extends AppCompatActivity {

    public static final String EXTRA_IMAGE_URI = "imageUri";
    public static final String EXTRA_RESULT_TEXT = "resultText";

    private TextView tvReaderTitle;
    private TextView tvMlResult;
    private ImageView imgSelected;
    private Button btnEditResults;

    private String readerType;
    private String readerTitle;

    private Uri selectedImageUri;
    private Uri currentCameraUri;
    private String currentResultText = "";

    private ActivityResultLauncher<String> cameraPermissionLauncher;
    private ActivityResultLauncher<Uri> cameraLauncher;
    private ActivityResultLauncher<String> galleryLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_analyse);

        tvReaderTitle = findViewById(R.id.tvReaderTitle);
        tvMlResult = findViewById(R.id.tvMlResult);
        imgSelected = findViewById(R.id.imgSelected);
        Button btnOpenCamera = findViewById(R.id.btnOpenCamera);
        Button btnLoadImage = findViewById(R.id.btnLoadImage);
        btnEditResults = findViewById(R.id.btnEditResults);

        readerType = getIntent().getStringExtra(MainActivity.EXTRA_READER_TYPE);
        readerTitle = getIntent().getStringExtra(MainActivity.EXTRA_READER_TITLE);
        int imageResId = getIntent().getIntExtra(MainActivity.EXTRA_IMAGE_RES_ID, R.drawable.barcode);

        if (readerType == null) {
            readerType = "BARCODE";
        }

        if (readerTitle == null) {
            readerTitle = "Barcode Reader";
        }

        tvReaderTitle.setText("Get Image from Camera or Gallery");
        imgSelected.setImageResource(imageResId);

        setupActivityResultLaunchers();

        btnOpenCamera.setOnClickListener(view -> checkCameraPermissionAndOpenCamera());
        btnLoadImage.setOnClickListener(view -> galleryLauncher.launch("image/*"));
        btnEditResults.setOnClickListener(view -> openEditActivity());
    }

    private void setupActivityResultLaunchers() {
        cameraPermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(),
                isGranted -> {
                    if (isGranted) {
                        openCamera();
                    } else {
                        Toast.makeText(this, "Camera permission is required.", Toast.LENGTH_SHORT).show();
                    }
                }
        );

        cameraLauncher = registerForActivityResult(
                new ActivityResultContracts.TakePicture(),
                success -> {
                    if (success && currentCameraUri != null) {
                        selectedImageUri = currentCameraUri;
                        imgSelected.setImageURI(selectedImageUri);
                        processImageWithMlKit(selectedImageUri);
                    } else {
                        Toast.makeText(this, "No camera image captured.", Toast.LENGTH_SHORT).show();
                    }
                }
        );

        galleryLauncher = registerForActivityResult(
                new ActivityResultContracts.GetContent(),
                uri -> {
                    if (uri != null) {
                        selectedImageUri = uri;
                        imgSelected.setImageURI(selectedImageUri);
                        processImageWithMlKit(selectedImageUri);
                    } else {
                        Toast.makeText(this, "No gallery image selected.", Toast.LENGTH_SHORT).show();
                    }
                }
        );
    }

    private void checkCameraPermissionAndOpenCamera() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            openCamera();
        } else {
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA);
        }
    }

    private void openCamera() {
        try {
            File imageDirectory = new File(getCacheDir(), "images");

            if (!imageDirectory.exists()) {
                imageDirectory.mkdirs();
            }

            File imageFile = new File(imageDirectory, "camera_" + System.currentTimeMillis() + ".jpg");

            currentCameraUri = FileProvider.getUriForFile(
                    this,
                    getPackageName() + ".provider",
                    imageFile
            );

            cameraLauncher.launch(currentCameraUri);

        } catch (Exception e) {
            Toast.makeText(this, "Unable to open camera: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void processImageWithMlKit(Uri imageUri) {
        try {
            tvReaderTitle.setText(readerTitle);
            tvMlResult.setText("Processing image...");
            btnEditResults.setVisibility(Button.GONE);

            InputImage inputImage = InputImage.fromFilePath(this, imageUri);

            if ("BARCODE".equals(readerType)) {
                processBarcode(inputImage);
            } else if ("CONTENT".equals(readerType)) {
                processContent(inputImage);
            } else if ("TEXT".equals(readerType)) {
                processText(inputImage);
            } else {
                currentResultText = "Unknown reader type.";
                tvMlResult.setText(currentResultText);
                btnEditResults.setVisibility(Button.VISIBLE);
            }

        } catch (Exception e) {
            tvReaderTitle.setText(readerTitle);
            currentResultText = "Failed to process image: " + e.getMessage();
            tvMlResult.setText(currentResultText);
            btnEditResults.setVisibility(Button.VISIBLE);
        }
    }

    private void processBarcode(InputImage inputImage) {
        BarcodeScannerOptions options = new BarcodeScannerOptions.Builder()
                .setBarcodeFormats(
                        Barcode.FORMAT_QR_CODE,
                        Barcode.FORMAT_CODE_128,
                        Barcode.FORMAT_CODE_39,
                        Barcode.FORMAT_CODE_93,
                        Barcode.FORMAT_CODABAR,
                        Barcode.FORMAT_EAN_13,
                        Barcode.FORMAT_EAN_8,
                        Barcode.FORMAT_ITF,
                        Barcode.FORMAT_UPC_A,
                        Barcode.FORMAT_UPC_E,
                        Barcode.FORMAT_PDF417,
                        Barcode.FORMAT_AZTEC,
                        Barcode.FORMAT_DATA_MATRIX
                )
                .build();

        BarcodeScanner scanner = BarcodeScanning.getClient(options);

        scanner.process(inputImage)
                .addOnSuccessListener(barcodes -> {
                    StringBuilder resultBuilder = new StringBuilder();
                    resultBuilder.append("Detected barcode:\n");

                    if (barcodes.isEmpty()) {
                        resultBuilder.append("No barcode or QR code found.");
                    } else {
                        int count = 1;

                        for (Barcode barcode : barcodes) {
                            String rawValue = barcode.getRawValue();

                            if (rawValue == null || rawValue.trim().isEmpty()) {
                                rawValue = "No readable barcode value.";
                            }

                            resultBuilder.append(count)
                                    .append(". ")
                                    .append(rawValue)
                                    .append("\n");

                            count++;
                        }
                    }

                    currentResultText = resultBuilder.toString().trim();
                    tvReaderTitle.setText(readerTitle);
                    tvMlResult.setText(currentResultText);
                    btnEditResults.setVisibility(Button.VISIBLE);
                })
                .addOnFailureListener(e -> {
                    currentResultText = "Detected barcode:\nBarcode scanning failed: " + e.getMessage();
                    tvReaderTitle.setText(readerTitle);
                    tvMlResult.setText(currentResultText);
                    btnEditResults.setVisibility(Button.VISIBLE);
                })
                .addOnCompleteListener(task -> scanner.close());
    }

    private void processContent(InputImage inputImage) {
        ImageLabeler labeler = ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS);

        labeler.process(inputImage)
                .addOnSuccessListener(labels -> {
                    StringBuilder resultBuilder = new StringBuilder();
                    resultBuilder.append("Recognised image content:\n");

                    if (labels.isEmpty()) {
                        resultBuilder.append("No image content labels found.");
                    } else {
                        int count = 1;

                        for (ImageLabel label : labels) {
                            String labelText = label.getText();
                            float confidence = label.getConfidence() * 100;

                            resultBuilder.append(count)
                                    .append(". ")
                                    .append(labelText)
                                    .append(" - ")
                                    .append(String.format(Locale.getDefault(), "%.1f", confidence))
                                    .append("% confidence")
                                    .append("\n");

                            count++;
                        }
                    }

                    currentResultText = resultBuilder.toString().trim();
                    tvReaderTitle.setText(readerTitle);
                    tvMlResult.setText(currentResultText);
                    btnEditResults.setVisibility(Button.VISIBLE);
                })
                .addOnFailureListener(e -> {
                    currentResultText = "Recognised image content:\nImage content analysis failed: " + e.getMessage();
                    tvReaderTitle.setText(readerTitle);
                    tvMlResult.setText(currentResultText);
                    btnEditResults.setVisibility(Button.VISIBLE);
                })
                .addOnCompleteListener(task -> labeler.close());
    }

    private void processText(InputImage inputImage) {
        TextRecognizer recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);

        recognizer.process(inputImage)
                .addOnSuccessListener(text -> {
                    String detectedText = text.getText();
                    StringBuilder resultBuilder = new StringBuilder();
                    resultBuilder.append("Extracted text:\n");

                    if (detectedText.trim().isEmpty()) {
                        resultBuilder.append("No text found in the image.");
                    } else {
                        String[] lines = detectedText.trim().split("\\r?\\n");
                        int count = 1;

                        for (String line : lines) {
                            String cleanLine = line.trim();

                            if (!cleanLine.isEmpty()) {
                                resultBuilder.append(count)
                                        .append(". ")
                                        .append(cleanLine)
                                        .append("\n");

                                count++;
                            }
                        }
                    }

                    currentResultText = resultBuilder.toString().trim();
                    tvReaderTitle.setText(readerTitle);
                    tvMlResult.setText(currentResultText);
                    btnEditResults.setVisibility(Button.VISIBLE);
                })
                .addOnFailureListener(e -> {
                    currentResultText = "Extracted text:\nText recognition failed: " + e.getMessage();
                    tvReaderTitle.setText(readerTitle);
                    tvMlResult.setText(currentResultText);
                    btnEditResults.setVisibility(Button.VISIBLE);
                })
                .addOnCompleteListener(task -> recognizer.close());
    }

    private void openEditActivity() {
        if (selectedImageUri == null) {
            Toast.makeText(this, "Choose an image first.", Toast.LENGTH_SHORT).show();
            return;
        }

        Intent intent = new Intent(AnalyseActivity.this, EditActivity.class);
        intent.putExtra(MainActivity.EXTRA_READER_TITLE, readerTitle);
        intent.putExtra(EXTRA_RESULT_TEXT, currentResultText);
        intent.putExtra(EXTRA_IMAGE_URI, selectedImageUri.toString());
        startActivity(intent);
    }
}