package com.example.mt_assignment_2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    public static final String EXTRA_READER_TYPE = "readerType";
    public static final String EXTRA_READER_TITLE = "readerTitle";
    public static final String EXTRA_IMAGE_RES_ID = "imageResId";

    private ImageView imgBarcode;
    private ImageView imgContent;
    private ImageView imgText;

    private TextView tvBarcodeReader;
    private TextView tvContentReader;
    private TextView tvTextReader;

    private Button btnListOfAnalysedImages;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imgBarcode = findViewById(R.id.imgBarcode);
        imgContent = findViewById(R.id.imgContent);
        imgText = findViewById(R.id.imgText);

        tvBarcodeReader = findViewById(R.id.tvBarcodeReader);
        tvContentReader = findViewById(R.id.tvContentReader);
        tvTextReader = findViewById(R.id.tvTextReader);

        btnListOfAnalysedImages = findViewById(R.id.btnListOfAnalysedImages);

        imgBarcode.setOnClickListener(view ->
                openAnalyseActivity("BARCODE", "Barcode Reader", R.drawable.barcode));

        tvBarcodeReader.setOnClickListener(view ->
                openAnalyseActivity("BARCODE", "Barcode Reader", R.drawable.barcode));

        imgContent.setOnClickListener(view ->
                openAnalyseActivity("CONTENT", "Content Reader", R.drawable.content));

        tvContentReader.setOnClickListener(view ->
                openAnalyseActivity("CONTENT", "Content Reader", R.drawable.content));

        imgText.setOnClickListener(view ->
                openAnalyseActivity("TEXT", "Text Reader", R.drawable.text));

        tvTextReader.setOnClickListener(view ->
                openAnalyseActivity("TEXT", "Text Reader", R.drawable.text));

        btnListOfAnalysedImages.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, ListActivity.class);
            startActivity(intent);
        });
    }

    private void openAnalyseActivity(String readerType, String readerTitle, int imageResId) {
        Intent intent = new Intent(MainActivity.this, AnalyseActivity.class);
        intent.putExtra(EXTRA_READER_TYPE, readerType);
        intent.putExtra(EXTRA_READER_TITLE, readerTitle);
        intent.putExtra(EXTRA_IMAGE_RES_ID, imageResId);
        startActivity(intent);
    }
}