package com.example.mt_assignment_2;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class ImageItemAdapter extends BaseAdapter {

    private final Context context;
    private final ArrayList<ImageItem> imageItems;

    public ImageItemAdapter(Context context, ArrayList<ImageItem> imageItems) {
        this.context = context;
        this.imageItems = imageItems;
    }

    @Override
    public int getCount() {
        return imageItems.size();
    }

    @Override
    public Object getItem(int position) {
        return imageItems.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public void updateItems(ArrayList<ImageItem> newItems) {
        imageItems.clear();
        imageItems.addAll(newItems);
        notifyDataSetChanged();
    }

    @SuppressLint("SetTextI18n")
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View itemView = convertView;

        if (itemView == null) {
            itemView = LayoutInflater.from(context).inflate(R.layout.list_item_image, parent, false);
        }

        ImageView imgItem = itemView.findViewById(R.id.imgItem);
        TextView tvItemText = itemView.findViewById(R.id.tvItemText);

        ImageItem item = imageItems.get(position);

        if (position % 2 == 0) {
            itemView.setBackgroundColor(Color.rgb(238, 238, 238));
        } else {
            itemView.setBackgroundColor(Color.WHITE);
        }

        String title = item.getTitle() == null ? "Untitled" : item.getTitle();
        String result = item.getResultText() == null ? "" : item.getResultText();

        if (result.length() > 80) {
            result = result.substring(0, 80) + "...";
        }

        tvItemText.setText(title + "\n" + result);

        Uri imageUri = ImageStorage.getImageUri(context, item.getImageFileName());

        if (imageUri != null) {
            imgItem.setImageURI(imageUri);
        } else {
            imgItem.setImageResource(R.drawable.barcode);
        }

        return itemView;
    }
}