package com.example.mt_assignment_2;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class DetailActivity extends AppCompatActivity {

    private TextView tvDetailReaderTitle;
    private TextView tvDetailMlResult;
    private ImageView imgDetail;
    private Button btnEdit;
    private Button btnDelete;
    private Button btnCancel;

    private DatabaseReference databaseReference;
    private ValueEventListener valueEventListener;

    private String itemId;
    private ImageItem currentItem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        tvDetailReaderTitle = findViewById(R.id.tvDetailReaderTitle);
        tvDetailMlResult = findViewById(R.id.tvDetailMlResult);
        imgDetail = findViewById(R.id.imgDetail);
        btnEdit = findViewById(R.id.btnEdit);
        btnDelete = findViewById(R.id.btnDelete);
        btnCancel = findViewById(R.id.btnCancel);

        itemId = getIntent().getStringExtra(EditActivity.EXTRA_ITEM_ID);

        if (itemId == null || itemId.trim().isEmpty()) {
            Toast.makeText(this, "Item ID is missing.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        databaseReference = FirebaseDatabase.getInstance()
                .getReference("analysedImages")
                .child(itemId);

        btnEdit.setOnClickListener(view -> openEditActivity());

        btnDelete.setOnClickListener(view -> deleteCurrentItem());

        btnCancel.setOnClickListener(view -> finish());

        loadItemDetails();
    }

    private void loadItemDetails() {
        valueEventListener = databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                currentItem = snapshot.getValue(ImageItem.class);

                if (currentItem == null) {
                    Toast.makeText(DetailActivity.this, "Item no longer exists.", Toast.LENGTH_SHORT).show();
                    finish();
                    return;
                }

                if (currentItem.getId() == null) {
                    currentItem.setId(itemId);
                }

                tvDetailReaderTitle.setText(currentItem.getTitle());
                tvDetailMlResult.setText(currentItem.getResultText());

                Uri imageUri = ImageStorage.getImageUri(DetailActivity.this, currentItem.getImageFileName());

                if (imageUri != null) {
                    imgDetail.setImageURI(imageUri);
                } else {
                    imgDetail.setImageResource(R.drawable.barcode);
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Toast.makeText(DetailActivity.this, "Firebase load failed: " + error.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    private void openEditActivity() {
        if (currentItem == null) {
            Toast.makeText(this, "No item loaded.", Toast.LENGTH_SHORT).show();
            return;
        }

        Intent intent = new Intent(DetailActivity.this, EditActivity.class);
        intent.putExtra(EditActivity.EXTRA_ITEM_ID, currentItem.getId());
        intent.putExtra(MainActivity.EXTRA_READER_TITLE, currentItem.getTitle());
        intent.putExtra(AnalyseActivity.EXTRA_RESULT_TEXT, currentItem.getResultText());
        intent.putExtra(EditActivity.EXTRA_IMAGE_FILE_NAME, currentItem.getImageFileName());
        startActivity(intent);
    }

    private void deleteCurrentItem() {
        if (currentItem == null) {
            Toast.makeText(this, "No item loaded.", Toast.LENGTH_SHORT).show();
            return;
        }

        String imageFileName = currentItem.getImageFileName();

        databaseReference.removeValue()
                .addOnSuccessListener(unused -> {
                    ImageStorage.deleteImage(DetailActivity.this, imageFileName);
                    Toast.makeText(DetailActivity.this, "Deleted successfully.", Toast.LENGTH_SHORT).show();
                    finish();
                })
                .addOnFailureListener(e ->
                        Toast.makeText(DetailActivity.this, "Delete failed: " + e.getMessage(), Toast.LENGTH_LONG).show()
                );
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (databaseReference != null && valueEventListener != null) {
            databaseReference.removeEventListener(valueEventListener);
        }
    }
}