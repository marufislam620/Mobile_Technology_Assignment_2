package com.example.mt_assignment_2;

import android.content.Context;
import android.net.Uri;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class ImageStorage {

    private static final String IMAGE_FOLDER = "images";

    public static File getImageDirectory(Context context) {
        File directory = new File(context.getFilesDir(), IMAGE_FOLDER);

        if (!directory.exists()) {
            directory.mkdirs();
        }

        return directory;
    }

    public static String copyImageToInternalStorage(Context context, Uri imageUri) throws Exception {
        String fileName = "image_" + System.currentTimeMillis() + ".jpg";

        File imageDirectory = getImageDirectory(context);
        File destinationFile = new File(imageDirectory, fileName);

        InputStream inputStream = context.getContentResolver().openInputStream(imageUri);

        if (inputStream == null) {
            throw new Exception("Unable to open selected image.");
        }

        OutputStream outputStream = new FileOutputStream(destinationFile);

        byte[] buffer = new byte[4096];
        int bytesRead;

        while ((bytesRead = inputStream.read(buffer)) != -1) {
            outputStream.write(buffer, 0, bytesRead);
        }

        outputStream.flush();
        outputStream.close();
        inputStream.close();

        return fileName;
    }

    public static Uri getImageUri(Context context, String imageFileName) {
        if (imageFileName == null || imageFileName.trim().isEmpty()) {
            return null;
        }

        File imageFile = new File(getImageDirectory(context), imageFileName);

        if (!imageFile.exists()) {
            return null;
        }

        return Uri.fromFile(imageFile);
    }

    public static void deleteImage(Context context, String imageFileName) {
        if (imageFileName == null || imageFileName.trim().isEmpty()) {
            return;
        }

        File imageFile = new File(getImageDirectory(context), imageFileName);

        if (imageFile.exists()) {
            imageFile.delete();
        }
    }
}