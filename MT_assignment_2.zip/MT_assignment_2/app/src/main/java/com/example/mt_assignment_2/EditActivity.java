package com.example.mt_assignment_2;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class EditActivity extends AppCompatActivity {

    public static final String EXTRA_ITEM_ID = "itemId";
    public static final String EXTRA_IMAGE_FILE_NAME = "imageFileName";

    private EditText edtReaderTitle;
    private EditText edtMlResult;
    private ImageView imgEdit;
    private Button btnSave;

    private DatabaseReference databaseReference;

    private String itemId;
    private String imageUriString;
    private String imageFileName;
    private boolean isEditingExistingItem = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        edtReaderTitle = findViewById(R.id.edtReaderTitle);
        edtMlResult = findViewById(R.id.edtMlResult);
        imgEdit = findViewById(R.id.imgEdit);
        btnSave = findViewById(R.id.btnSave);

        databaseReference = FirebaseDatabase.getInstance().getReference("analysedImages");

        readIntentData();

        btnSave.setOnClickListener(view -> saveImageItem());
    }

    private void readIntentData() {
        itemId = getIntent().getStringExtra(EXTRA_ITEM_ID);

        String title = getIntent().getStringExtra(MainActivity.EXTRA_READER_TITLE);
        String result = getIntent().getStringExtra(AnalyseActivity.EXTRA_RESULT_TEXT);

        imageUriString = getIntent().getStringExtra(AnalyseActivity.EXTRA_IMAGE_URI);
        imageFileName = getIntent().getStringExtra(EXTRA_IMAGE_FILE_NAME);

        isEditingExistingItem = itemId != null && !itemId.trim().isEmpty();

        if (title != null) {
            edtReaderTitle.setText(title);
        }

        if (result != null) {
            edtMlResult.setText(result);
        }

        if (imageUriString != null) {
            imgEdit.setImageURI(Uri.parse(imageUriString));
        } else if (imageFileName != null) {
            Uri savedImageUri = ImageStorage.getImageUri(this, imageFileName);

            if (savedImageUri != null) {
                imgEdit.setImageURI(savedImageUri);
            }
        }
    }

    private void saveImageItem() {
        String title = edtReaderTitle.getText().toString().trim();
        String resultText = edtMlResult.getText().toString().trim();

        if (title.isEmpty()) {
            edtReaderTitle.setError("Reader title is required");
            return;
        }

        if (resultText.isEmpty()) {
            edtMlResult.setError("Result text is required");
            return;
        }

        if (isEditingExistingItem) {
            updateExistingItem(title, resultText);
        } else {
            saveNewItem(title, resultText);
        }
    }

    private void saveNewItem(String title, String resultText) {
        if (imageUriString == null || imageUriString.trim().isEmpty()) {
            Toast.makeText(this, "Image is missing.", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            Uri imageUri = Uri.parse(imageUriString);
            String savedImageFileName = ImageStorage.copyImageToInternalStorage(this, imageUri);

            String newItemId = databaseReference.push().getKey();

            if (newItemId == null) {
                Toast.makeText(this, "Unable to create Firebase record.", Toast.LENGTH_SHORT).show();
                return;
            }

            ImageItem imageItem = new ImageItem(
                    newItemId,
                    title,
                    resultText,
                    savedImageFileName,
                    System.currentTimeMillis()
            );

            databaseReference.child(newItemId).setValue(imageItem)
                    .addOnSuccessListener(unused -> {
                        Toast.makeText(this, "Saved successfully.", Toast.LENGTH_SHORT).show();
                        openListActivity();
                    })
                    .addOnFailureListener(e ->
                            Toast.makeText(this, "Save failed: " + e.getMessage(), Toast.LENGTH_LONG).show()
                    );

        } catch (Exception e) {
            Toast.makeText(this, "Image save failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void updateExistingItem(String title, String resultText) {
        databaseReference.child(itemId).child("title").setValue(title);
        databaseReference.child(itemId).child("resultText").setValue(resultText)
                .addOnSuccessListener(unused -> {
                    Toast.makeText(this, "Updated successfully.", Toast.LENGTH_SHORT).show();
                    openListActivity();
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Update failed: " + e.getMessage(), Toast.LENGTH_LONG).show()
                );
    }

    private void openListActivity() {
        Intent intent = new Intent(EditActivity.this, ListActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
        finish();
    }
}